#pragma once

#ifdef _TRACK_STATS

namespace Statistics {
    double encrypt_time;
    double decrypt_time;
    double setup_time;
}
#endif